# Author: Javier Abascal Carrasco
# Copyright: EOI
# Class: Curso acad�mico 2021
# Script: 1. Primeros pasos con R

#######################################################################
# Informaci�n B�sica
#######################################################################

# las almohadillas sirven para escribir comentarios. Estos no son ejecutados en la consola
# Atajos de teclado fundamentales
# - Ctrl + Enter --> Ejecuta la linea actual
# - Ctrl + 1 --> Te desplaza a la regi�n de "Source". Donde se editan archivos
# - Ctrl + 2 --> Te desplaza a la regi�n de "Console". Donde se ejecutan instrucciones
# - Tab --> Sirve para autocompletar c�digo, funciones y variables
# - ?nombre_de_la_funcion --> Abre la documentaci�n de la funci�n dentro de RStudio
# - [Dentro de la regi�n "Console"] flecha hacia arriba, --> Escribe el c�digo ejecutado anteriormente
# - Hoy en d�a "<-" es igual a "=" salvo para argumentos de las funciones
# - Para caracteres " (dobles comillas) es lo mismo que ' (comillas simple)


#######################################################################
# Primeros Pasos con R
#######################################################################
# Ver y fijar el "Working Directory" - directorio de trabajo
getwd()
setwd("C:/Users/Javie/Documents/1. Trabajo_Universidad/EOI/EOI Online ML e IA 2021-02-23/Contenidos R/R Code")

# Informaci�n general sobre la sesi�n. �til para saber los paquetes cargados
sessionInfo() 

# Installar un paquete en R
install.packages("ggplot2")
# Cargar un paquete a la sesi�n de trabajo actual de R
library(ggplot2)
??ggplot2

# Creamos unos datos ficticios y vemos las operaciones b�sicas
# En R todo es un objeto, como otros lenguajes orientados a objetos
# La asignaci�n de puede realizar mediante el = o la flecha <-
a <- "Hello World"
a
a = "Hello World"
a
x <- c(1,2,3,4)
x
x + x
# Listas o vectores en R
c(x,x)
x[1]
x[1:3]
rm(x)
x
x = c(1,2,3,4)

# Algunos ejemplos de Funciones b�sicas. Buscar la ayuda de ellas para entender que es lo que hacen
length(x)
?length
class(x)
str(x)

# factores (�tiles en R para ahorrar memoria. Es decir, es la forma correcta de almacenar
# variables categ�ricas). Ejemplo de uso -> https://www.tutorialspoint.com/r/r_factors.htm#:~:text=Factors%20are%20the%20data%20objects,limited%20number%20of%20unique%20values.
x = factor(c(1,2,3,1,2,3,3,3,3),levels = c(1,2,3), 
           labels = c("uno","dos","tres"))
x
x[1]

# Creaci�n de una matriz
x <- matrix(data=c(1,2,3,4,5,6), nrow=2, ncol=3)

# Operaciones sobre matrices (o vectores tambi�n. Elemento a elemento)
sqrt(x)
x^6
x = x^6

# Generaci�n de una distribuci�n

# IMPORTANTE !!!!
# Fija la semilla de la ejecuci�n aleatoria. Esto nos permite reproducir
# el experimento.
set.seed(3) 
x = rnorm(400, mean=50) #sd que es la varianza puede ser especificada si es necesario
y = rnorm(400, mean=100)

# Representar los datos en un "Scatter plot"
# IMPORTANTE! Si los m�rgenes de la regi�n de "Plots" es demasiado peque�a, 
# Rstudio puede dar un error al intentar dibujajr la gr�fica
plot(x,y)

# Guardar la imagen en un pdf
pdf("figureTest.pdf")
plot(x,y,col="green")
dev.off()


