# Author: Javier Abascal Carrasco
# Copyright: EOI
# Class: Curso acad�mico 2021
# Script: 4. Machine Learning con R (primera parte)

setwd("C:/Users/Javie/Documents/1. Trabajo_Universidad/EOI/EOI Online ML e IA 2021-02-23/Contenidos R/R Code")
# Ejercicio 1 - Time Series Analysis
#######################################################################

# Vamos a utilizar el dataset de Kaggle UK_CAR_ACCIDENTS_05_15 modificado
# https://www.kaggle.com/silicon99/dft-accident-data
# El dataset contiene los accidentes de tr�fico en esos 10 a�os. Las variables son:
# Fecha
# D�a de la semana
# Flag indicando si era un d�a festivo en UK (Bank Holidays)
# Tipo de vacaci�n

# Objetivo --> Usando los datos entre 2005 y 2014 predecir los accidentes para 2015

# Fijamos la seed aleatoria del experimento
set.seed(12345)

# Cargamos y Exploramos el dataset
x = read.csv("uk_car_accidents_05_15.csv")
head(x)
tail(x)
str(x)
plot(x$ds, x$accident_ct, main="UK Car Accidentes 2005-2015", type= "b")

# Fijamos el formato de la fecha a tipo "Date"
x$ds = as.Date(x$ds, format = "%Y-%m-%d")

# Buscamos si existe "missing points"
anyNA(x$accident_ct)
anyNA(x$ds)

# Creamos un objeto "Time Series", es decir, serie temporal
install.packages("lubridate")
library(lubridate)
x_ts = ts(x$accident_ct, start = decimal_date(as.Date("2005-01-01")), frequency = 365)
plot(x_ts)

# Descomposici�n de la serie en Seasonal, Trend and Noise
plot(stl(x_ts, "per"))

# Preparamos el Train (2005-2014) & Test dataset (2015)
# El conjunto de test solo debe de utilizarse para calcular la calidad del modelo
l = length(x_ts) # n�mero de d�as totales
x_train = ts(x$accident_ct[1:(l-365)], start = decimal_date(as.Date("2005-01-01")), frequency = 365)
x_test = ts(x$accident_ct[(l-365+1):length(x_ts)], start = decimal_date(as.Date("2015-01-01")), frequency = 365)

################################################
# Generamos un modelo AUTOARIMA (parametric model)
################################################
# https://www.rdocumentation.org/packages/forecast/versions/8.1/topics/auto.arima
install.packages("forecast")
library(forecast)

# Solo utilizando TIME SERIES - Ning�n external regressors
fit_aa = auto.arima(x_train)
x_aa_forecast = forecast(fit_aa, h = 365)
plot(x_aa_forecast)
points(x_test, type = "b", col="red")
plot(x_aa_forecast, xlim = c(decimal_date(as.Date("2014-01-01")), decimal_date(as.Date("2016-01-01"))))
points(x_test, type = "b", col="red")

# Calculo del Error medio en porcentaje (Mean Absolute Percentage Error) y 
# RMSE (Root mean squared error)
# https://www.otexts.org/fpp/2/5
actual = c(x_test)
predicted = x_aa_forecast$mean
MAPE_arima = mean(abs((actual-predicted)/actual) * 100)
RMSE_arima = sqrt(mean((actual-predicted)^2))

# Con TIME SERIES + external regressors
fit_aa = auto.arima(x_train, xreg= cbind(x$week_day[1:(l-365)], x$holiday_flag[1:(l-365)]) )
x_aa_forecast = forecast(fit_aa, xreg= cbind(x$week_day[(l-365+1):l], x$holiday_flag[(l-365+1):l]), h = 365)
plot(x_aa_forecast)
points(x_test, type = "b", col="red")
plot(x_aa_forecast, xlim = c(decimal_date(as.Date("2014-01-01")), decimal_date(as.Date("2016-01-01"))))
points(x_test, type = "b", col="red")

# Calculo del Error medio en porcentaje (Mean Absolute Percentage Error) y 
# RMSE (Root mean squared error)
# https://www.otexts.org/fpp/2/5
actual = c(x_test)
predicted = x_aa_forecast$mean
MAPE_arima_regressors = mean(abs((actual-predicted)/actual) * 100)
RMSE_arima_regressors = sqrt(mean((actual-predicted)^2))

################################################
# Generamos un modelo PROPHET (Non parametric model)
################################################
# https://facebookincubator.github.io/prophet/docs/quick_start.html
# pkg_url <- "https://cran.rstudio.com/src/contrib/Archive/dplyr/dplyr_0.4.3.tar.gz"
# install.packages(pkg_url, repos = NULL, type = "source")
install.packages("prophet")
library(prophet)

# Prophet requiere un objeto data-frame con las columnas "ds" y "y"
x_train_prophet = data.frame(ds= x$ds[1:(l-365)],y = x$accident_ct[1:(l-365)])

# Prophet SIN Vacaciones
fit_prophet = prophet(x_train_prophet,
                      growth = "linear",
                      yearly.seasonality = TRUE,
                      weekly.seasonality = TRUE)

future <- make_future_dataframe(fit_prophet, periods = 365)
x_prophet_forecast = predict(fit_prophet,future)
prophet_plot_components(fit_prophet, x_prophet_forecast)
plot(fit_prophet, x_prophet_forecast)

plot(x_train, xlim = c(decimal_date(as.Date("2014-01-01")), decimal_date(as.Date("2016-01-01"))))
points(decimal_date(x_prophet_forecast$ds[(l-365+1):l]), 
       x_prophet_forecast$yhat[(l-365+1):l],
       type="b", col="blue")
points(x_test, type="b", col="red")


# Calculo del Error medio en porcentaje (Mean Absolute Percentage Error) y 
# RMSE (Root mean squared error)
# https://www.otexts.org/fpp/2/5
actual = c(x_test)
predicted = x_prophet_forecast$yhat[(l-365+1):l]
MAPE_prophet = mean(abs((actual-predicted)/actual) * 100)
RMSE_prophet = sqrt(mean((actual-predicted)^2))

# Prophet CON Vacaciones
df_holidays = data.frame(holiday = "uk_bank_holiday", 
                         ds = x[x$holiday_flag==1,"ds"],
                         lower_window = 0,
                         upper_window = 1)

fit_prophet = prophet(x_train_prophet,
                      growth = "linear",
                      yearly.seasonality = TRUE,
                      weekly.seasonality = TRUE,
                      holidays = df_holidays)

future <- make_future_dataframe(fit_prophet, periods = 365)
x_prophet_forecast = predict(fit_prophet,future)
prophet_plot_components(fit_prophet, x_prophet_forecast)
plot(fit_prophet, x_prophet_forecast)

plot(x_train, xlim = c(decimal_date(as.Date("2014-01-01")), decimal_date(as.Date("2016-01-01"))))
points(decimal_date(x_prophet_forecast$ds[(l-365+1):l]), 
       x_prophet_forecast$yhat[(l-365+1):l],
       type="b", col="blue")
points(x_test, type="b", col="red")

# Calculo del Error medio en porcentaje (Mean Absolute Percentage Error) y 
# RMSE (Root mean squared error)
# https://www.otexts.org/fpp/2/5
actual = c(x_test)
predicted = x_prophet_forecast$yhat[(l-365+1):l]
MAPE_prophet_vacaciones = mean(abs((actual-predicted)/actual) * 100)
RMSE_prophet_vacaciones = sqrt(mean((actual-predicted)^2))


################################################
# Generamos un modelo H�brido de Time Series (STACKING autom�tico)
################################################
# https://www.rdocumentation.org/packages/forecastHybrid/versions/1.0.8/topics/hybridModel
install.packages("forecastHybrid")
library(forecastHybrid)

# auto.arima  & nnetar & stlm
fit_hybrid_model = hybridModel(x_train, models = "nsa",
                               weights = "equal")
x_hybrid_forecast = forecast(fit_hybrid_model, h = 365)
plot(x_hybrid_forecast)
points(x_test, type = "b", col="red")
plot(x_hybrid_forecast, xlim = c(decimal_date(as.Date("2014-01-01")), decimal_date(as.Date("2016-01-01"))))
points(x_test, type = "b", col="red")

# Calculo del Error medio en porcentaje (Mean Absolute Percentage Error) y 
# RMSE (Root mean squared error)
# https://www.otexts.org/fpp/2/5
actual = c(x_test)
predicted = x_hybrid_forecast$mean
MAPE_hybrid = mean(abs((actual-predicted)/actual) * 100)
RMSE_hybrid = sqrt(mean((actual-predicted)^2))



