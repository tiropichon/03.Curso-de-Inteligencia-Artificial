# Author: Javier Abascal Carrasco
# Copyright: EOI
# Class: Curso acad�mico 2021
# Script: 2. DataFrame y manipulaci�n

#######################################################################
# Estructura de Datos y Data Profiling - Manipulaci�n del DataFrame
#######################################################################
# dataset
attach(mtcars)
?mtcars
x = mtcars
x
is.data.frame(mtcars)

# Exploraci�n de un dataset. Existen muchas formas de ver un dataset sin necesidad de imprimirlo al completo. 
# Esto es importante de hacer, porque en la realidad nos podemos encontrar con datasets de cientos de miles de filas y 
# centenares de columnas
dim(mtcars)
colnames(mtcars)
rownames(mtcars)
str(mtcars)
summary(mtcars)
head(mtcars)
tail(mtcars)

# Accediendo al DataFrame por referencia
mtcars # todo el dataframe
mtcars[,1] # acceder a la primera columna
mtcars[,"mpg"] # acceder a la columna "mpg"
mtcars[1:5,] # acceder a las 5 primeras filas
mtcars[1:10,c("hp","drat","vs")] # acceder a las 10 primeras filas de las columnas hp,drat y vs
mtcars$test = 1 # Crear una nueva columna llamada "test" con valor constante 1
mtcars 
mtcars$test <- NULL # Eliminar la columna "test"

# Seleccionar unas columnas espec�ficas
mycols <- c("am","mpg","cyl","carb")
mydata1 <- mtcars[ , which(names(mtcars) %in% mycols)]
mydata1

# Seleccionar todo MENOS unas columnas espec�ficas (s�mbolo - )
mycols <- c("am","mpg","cyl","carb")
mydata1 <- mtcars[ , - which(names(mtcars) %in% mycols)]
mydata1


# Filtrar un dataset - diferentes ejemplos
subset(mtcars, cyl==4)
subset(mtcars, cyl==4 & gear==4)
subset(mtcars, cyl==4 & gear!=4)
subset(mtcars, cyl==4 | gear==4)
nrow(subset(mtcars, cyl==4 | gear==4))
dim(subset(mtcars, cyl==4 | gear==4))
mtcars[mtcars$cyl==4 & mtcars$gear==4,]
unique(mtcars$cyl)

# Utilizar SQL para filtrar un dataset. Esto permite que las personas con conocimientos de SQL puedan trabajar con R
install.packages("sqldf")
library(sqldf)
sqldf("select * from mtcars where cyl=4 order by mpg")
sqldf("select * from mtcars where cyl=4 order by mpg", row.names=TRUE)

# nombre de las filas
rownames(mtcars)

# Transponer un data frame
t(mtcars)

# Aplicar una funci�n a todo el data frame
?apply
apply(mtcars, 2, mean) # Por columna
apply(mtcars, 1, mean) # Por fila

# Crear una funci�n
# Esta función devuelve 1 si el valor es mayor que 4 y 0 en otro caso.
filtro_4 <- function(column){
  if(column > 4){
    return(1)
  }
  else {
    return(0)
  }
}

# utilizar una funci�n para ver que funciona
filtro_4(10)
filtro_4(3)
# Applicamos la función sobre toda una columna del DataFrame
# Lo hacemos con "sapply" -> Apply a Function over a List or Vector
?sapply
mtcars$filtro_4_cyl <- sapply(mtcars$cyl, FUN=filtro_4) 
mtcars$filtro_4_cyl <- NULL


# Construimos ahora una tabla de mapeo para unir dos dataframes. 
# El objetivo es cambiar los valores 0 y 1 (0 = automatic, 1 = manual) de la columna "am" por automatico y manual
# Para ello vamos a utilizar la función MERGE
trans_code <- c(0,1)
trans_desc <- c("automatic","manual")
trans_mapping <- data.frame(trans_code, trans_desc)
trans_mapping


# Funci�n MERGE
x <- mtcars
# all.x or all.y para "left" or "right" join
y <- merge(x, trans_mapping, by.x=c("am"), by.y=c("trans_code"))
y


